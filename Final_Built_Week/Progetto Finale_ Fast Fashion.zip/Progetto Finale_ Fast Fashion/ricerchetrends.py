from pytrends.request import TrendReq

def get_total_searches(keywords, year):
    pytrends = TrendReq(hl='en-US', tz=360)
    pytrends.build_payload(keywords, cat=0, timeframe=f'{year}-01-01 {year}-12-31', geo='', gprop='')
    data = pytrends.interest_over_time()
    total_searches = {}
    for keyword in keywords:
        if keyword in data.columns:
            total_searches[keyword] = data[keyword].sum()
        else:
            total_searches[keyword] = 0
    return total_searches

if __name__ == "__main__":
    keywords = [ "subito.it", "shein","vestiti seconda mano", "vintage dress"]
    year = "2023"
    total_searches = get_total_searches(keywords, year)
    for keyword, count in total_searches.items():
        print(f"{keyword}- nel {year}: {count}")
